#include  <msp430.h>
#include "trx_rf_spi.h"
#include "chip_detect.h"
#include "freq_xosc_detect.h"
//#include "per_test.h"
#include "main_graphics.c"
#include "menu_system.h"
#include "menu_driver.h"
#include "sniff_mode.h"
//#include "chip_information.h"
//#include "easyLink.h"
   
#include "lcd_dogm128_6.h"
#include "bsp.h"
#include "bsp_key.h"
#include "bsp_led.h"
/******************************************************************************
* GLOBAL VARIABLES
*/
extern uint8  mclkFrequency;



menu_t mainMenu;
//menu_t contrastMenu;

menuItem_t mainMenuItems[] =
{
  {0x00,"3","RX Sniff Test"              ,0,&sniffModeFrequencyMenu ,0,&sniffInitApp        ,0},
};

menu_t mainMenu =
{
  (menuItem_t*)mainMenuItems,   /* pItems          */
  0,                            /* pParentMenu     */
  0,                            /* pMenuGraphics   */
  "Main Menu",                  /* pTextHeader     */
  "1",                          /* pTextMenuItems  */
  1,                            /* nMenuItems      */
  0,                            /* nCurrentItem    */
  -1,                           /* nSelectedItem   */
  0,                            /* nScreen         */
  0                             /* reservedAreas   */
};


void main( void )
{
  // Init clocks and I/O 
  bspInit(BSP_SYS_CLK_16MHZ);
  
  // Init leds 
  bspLedInit(); 

  // Init Buttons
  bspKeyInit(BSP_KEY_MODE_POLL);
  
  // Initialize SPI interface to LCD (shared with SPI flash)
  bspIoSpiInit(BSP_FLASH_LCD_SPI, BSP_FLASH_LCD_SPI_SPD);  

  /* Init Buttons */
  bspKeyInit(BSP_KEY_MODE_ISR);
  bspKeyIntEnable(BSP_KEY_ALL);
  /* Init LCD and issue a welcome */
  lcdInit();
  lcdClear();
  // Instantiate tranceiver RF spi interface to SCLK ~ 4 MHz */
  //input clockDivider - SMCLK/clockDivider gives SCLK frequency
  trxRfSpiInterfaceInit(0x10);
//  
//  
//  /* MCU will stay in sleep until button is pressed */
//  __low_power_mode_3();
//  bspKeyPushed(BSP_KEY_ALL);
  //Clear screen
  lcdBufferClear(0);

  /* Menu Driver */
  menu_t *pCurrentMenu = &mainMenu;
  uint8 menuButtonsPressed;
  menuDisplay(pCurrentMenu);
  
  // ENTER RX SNIFF MODE
  pCurrentMenu = menuEnter(pCurrentMenu);
  menuDisplay(pCurrentMenu);
  __delay_cycles(20000000);
  
  // ENTER 434 MHz FREQUENCY MODE
  pCurrentMenu = menuEnter(pCurrentMenu);
  menuDisplay(pCurrentMenu);
  __delay_cycles(20000000);
  
  for (int i=0; i<5; ++i) {
    // ENTER TX
    pCurrentMenu = menuEnter(pCurrentMenu);
    menuDisplay(pCurrentMenu);
    __delay_cycles(20000000);
    
    // GO BACK
//    pCurrentMenu = menuBack(pCurrentMenu);
//    menuDisplay(pCurrentMenu);
//    __delay_cycles(20000000);
    
    // ENTER RX
    menuDown(pCurrentMenu);
    menuDisplay(pCurrentMenu);
    __delay_cycles(20000000);
    
    pCurrentMenu = menuEnter(pCurrentMenu);
    menuDisplay(pCurrentMenu);
    __delay_cycles(20000000);
    
    // GO BACK
    pCurrentMenu = menuBack(pCurrentMenu);
    menuDisplay(pCurrentMenu);
    __delay_cycles(20000000);
  }
  
  
//  while(1)
//  {
//    menuButtonsPressed = bspKeyPushed(BSP_KEY_ALL);
//    //pCurrentMenu = menuEnter(pCurrentMenu);
//    
//    switch(menuButtonsPressed)
//    {
//      case BSP_KEY_LEFT:
//        pCurrentMenu = menuBack(pCurrentMenu);
//        break;
//      case BSP_KEY_RIGHT:
//        pCurrentMenu = menuEnter(pCurrentMenu);
//        break;
//      case BSP_KEY_DOWN:
//        menuDown(pCurrentMenu);
//        break;
//      case BSP_KEY_UP:
//        menuUp(pCurrentMenu);
//        break;
//      default:
//        break;
//    }
//    
//    menuDisplay(pCurrentMenu);
//    
//    //__delay_cycles(20000000);
//    /* Enter low power mode while menu driver waits on user input */
//    __low_power_mode_3();
//  }
}


//
//
//static uint8 contrastApp(void **pVoid)
//{
//  uint16 c = (uint16)*pVoid;
//  lcdSetContrast(c&0x00FF);
//  return 0;
//}