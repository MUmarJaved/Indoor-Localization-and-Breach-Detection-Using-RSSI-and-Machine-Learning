ccxxxx_per_test_api.x : Defines the set of functions available to the per test. This constraints functionality
ccxxxx_spi.x               : Defines several sets of functions and constants that are used when doing spi com
                                  with trxeb(reusable). Complies with the macros implemented in ..\trxeb_rf_spi.h